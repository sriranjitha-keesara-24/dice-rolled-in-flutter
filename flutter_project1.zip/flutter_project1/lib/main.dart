import 'package:flutter/material.dart';
import 'package:project1/page_one.dart';
void main() {
  runApp(MaterialApp(
    home: Scaffold(
      appBar: AppBar(
        title: Text("My First Project"),
        centerTitle: true,
      ),
      body: MyApp(), // Use your custom widget here
      
    ),
  ));
}
