import 'package:flutter/material.dart';
import 'dart:math';
//using stateFullWidget
int changeDice = 2;
class DiceRolling extends StatefulWidget{
  @override
  State<DiceRolling> createState(){
    return _ImageStateFull(); //calling the constructor of bellow class.
  }

}
class _ImageStateFull extends State<DiceRolling>{
  //this is only for two images 
  //  var changeImage = "assets/images/rahul1.JPG";
  //   void clickOn(){
  //     setState(() {
  //       changeImage = "assets/images/rahul3.JPG";
  //     });
    
  //   }
  //this is for random images : for random images we use random import
  void clickOn(){
    
     setState(() {
       changeDice =Random().nextInt(5)+1;
     });
  }
  @override
  Widget build(BuildContext context){
    
    return Container(
      child:  Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment : CrossAxisAlignment.center,
        children: [Image.asset("assets/images/dice_$changeDice.jpg",width: 200,height: 200,),
        Padding(padding:EdgeInsetsGeometry.all(10)),
        TextButton(onPressed: clickOn,style: ButtonStyle(backgroundColor: MaterialStateProperty.all(Color.fromRGBO(8, 18, 218, 0.929))), child: Text("Next"))],
        
      ),
    );
  }
}