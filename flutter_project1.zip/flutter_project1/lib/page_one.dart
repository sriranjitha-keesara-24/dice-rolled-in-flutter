import 'package:flutter/material.dart';
import 'package:project1/stateFullWidgets.dart';
class MyApp extends StatelessWidget{
  @override
  Widget build(BuildContext context){
  
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [Color.fromRGBO(144, 18, 112, 0.651),Color.fromRGBO(104, 201, 35, 0.575),Color.fromRGBO(71, 224, 244, 0.551)],
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                  ),
      ),
      constraints: BoxConstraints.expand(),
      child:    
        DiceRolling(),
      
      );

  }
}
